HUDPlus Enhanced Patch
A20 - Version 1.0.1
Description and Updates


______________________________________________________________________________________________________________________
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Features


_____________________________________________________________________________________________________________________
1.  ABOUT AUTHOR
	-Name changed from RilesPlus to AuroraGiggleFairy (AGF)
	-Started playing 7d2d during Alpha 12
	-Started attempting to mod in Alpha 17
	-First published a mod during Alpha 18
	-Where to find:
		https://discord.gg/Vm5eyW6N4r
		https://7daystodiemods.com/
		https://www.nexusmods.com/7daystodie
		https://www.twitch.tv/AuroraGiggleFairy
		
		
______________________________________________________________________________________________________________________
2.  MOD PHILOSOPHY
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
		
	"The best mods rely on community involvement."
	
	
______________________________________________________________________________________________________________________
3.  Features

*****First, if you run into any conflicts, you may contact AuroraGiggleFairy via discord: https://discord.gg/Vm5eyW6N4r

*****You must turn EAC off for these other stats to appear... *****

*****All players must have this patch installed locally to use on a server... ****


Here are the additional stats included:
	-Food and Water now show both percentage AND amount
	-Lootstage is shown
	-Zombie Kills are shown
	-Player Deaths are shown



